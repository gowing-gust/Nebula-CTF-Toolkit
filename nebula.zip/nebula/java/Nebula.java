// ╔══════════════════════════════════════════════════════════╗
// ║               NEBULA CTF TOOLKIT — Java Engine          ║
// ║           Backend: Sessions, Reporting, Network         ║
// ║                       Version 1.0.0                     ║
// ╚══════════════════════════════════════════════════════════╝

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;
import java.time.*;
import java.time.format.*;
import java.security.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import org.json.simple.*;
import org.json.simple.parser.*;

// ── Main Entry Point ─────────────────────────────────────────────────────────

public class Nebula {

    public static final String VERSION = "1.0.0";
    public static final String ANSI_RESET  = "\u001B[0m";
    public static final String ANSI_GREEN  = "\u001B[92m";
    public static final String ANSI_CYAN   = "\u001B[96m";
    public static final String ANSI_YELLOW = "\u001B[93m";
    public static final String ANSI_RED    = "\u001B[91m";
    public static final String ANSI_PURPLE = "\u001B[95m";

    public static void main(String[] args) {
        NebulaCLI cli = new NebulaCLI();
        if (args.length > 0 && args[0].equalsIgnoreCase("--gui")) {
            SwingUtilities.invokeLater(() -> new NebulaDashboard().launch());
        } else {
            cli.run(args);
        }
    }

    public static void info(String msg)    { System.out.println(ANSI_CYAN   + "[*] " + ANSI_RESET + msg); }
    public static void ok(String msg)      { System.out.println(ANSI_GREEN  + "[+] " + ANSI_RESET + msg); }
    public static void warn(String msg)    { System.out.println(ANSI_YELLOW + "[!] " + ANSI_RESET + msg); }
    public static void error(String msg)   { System.out.println(ANSI_RED    + "[-] " + ANSI_RESET + msg); }
}

// ── Session Model ─────────────────────────────────────────────────────────────

class NebulaSessData {
    public String name;
    public String startedAt;
    public List<String> flags   = new ArrayList<>();
    public List<String> targets = new ArrayList<>();
    public List<Map<String, String>> notes = new ArrayList<>();
    public Map<String, List<Object>> results = new HashMap<>();

    public NebulaSessData(String name) {
        this.name      = name;
        this.startedAt = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }

    public void addFlag(String flag) {
        flag = flag.trim();
        if (!flag.isEmpty() && !flags.contains(flag)) {
            flags.add(flag);
            Nebula.ok("Flag saved: " + Nebula.ANSI_GREEN + flag + Nebula.ANSI_RESET);
        } else {
            Nebula.warn("Duplicate or empty flag.");
        }
    }

    public void addTarget(String target) {
        if (!targets.contains(target)) {
            targets.add(target);
            Nebula.ok("Target added: " + target);
        }
    }

    public void addNote(String title, String content) {
        Map<String, String> note = new HashMap<>();
        note.put("title", title);
        note.put("content", content);
        note.put("timestamp", LocalDateTime.now().toString());
        notes.add(note);
        Nebula.ok("Note added: " + title);
    }

    public void addResult(String module, Object data) {
        results.computeIfAbsent(module, k -> new ArrayList<>()).add(data);
    }

    public int totalResults() {
        return results.values().stream().mapToInt(List::size).sum();
    }

    public void printSummary() {
        System.out.println("\n" + Nebula.ANSI_PURPLE + "  ══ Session Summary ══" + Nebula.ANSI_RESET);
        System.out.println("  Name    : " + name);
        System.out.println("  Started : " + startedAt);
        System.out.println("  Targets : " + targets.size());
        System.out.println("  Flags   : " + Nebula.ANSI_GREEN + flags.size() + Nebula.ANSI_RESET);
        System.out.println("  Notes   : " + notes.size());
        System.out.println("  Results : " + totalResults());
        System.out.println();
    }
}

// ── Session Manager ──────────────────────────────────────────────────────────

class SessionManager {

    private static final Path SESSIONS_DIR = Path.of(System.getProperty("user.home"), ".nebula", "sessions");

    static {
        try {
            Files.createDirectories(SESSIONS_DIR);
        } catch (IOException e) {
            System.err.println("Warning: Could not create sessions directory: " + e.getMessage());
        }
    }

    public static String save(NebulaSessData session) {
        String filename = session.name + ".json";
        Path path = SESSIONS_DIR.resolve(filename);
        try (PrintWriter w = new PrintWriter(Files.newBufferedWriter(path))) {
            w.println("{");
            w.println("  \"name\": \"" + escapeJson(session.name) + "\",");
            w.println("  \"started\": \"" + session.startedAt + "\",");
            w.println("  \"flags\": " + toJsonArray(session.flags) + ",");
            w.println("  \"targets\": " + toJsonArray(session.targets) + ",");
            w.println("  \"notes\": " + notesToJson(session.notes) + ",");
            w.println("  \"result_count\": " + session.totalResults());
            w.println("}");
            Nebula.ok("Session saved: " + path);
            return path.toString();
        } catch (IOException e) {
            Nebula.error("Save failed: " + e.getMessage());
            return null;
        }
    }

    public static NebulaSessData load(String filename) {
        Path path = SESSIONS_DIR.resolve(filename);
        if (!Files.exists(path)) {
            path = Path.of(filename);
        }
        try {
            String content = Files.readString(path);
            JSONParser parser = new JSONParser();
            JSONObject obj = (JSONObject) parser.parse(content);
            NebulaSessData session = new NebulaSessData((String) obj.getOrDefault("name", "loaded"));
            session.startedAt = (String) obj.getOrDefault("started", session.startedAt);

            JSONArray flags = (JSONArray) obj.get("flags");
            if (flags != null) for (Object f : flags) session.flags.add(f.toString());

            JSONArray targets = (JSONArray) obj.get("targets");
            if (targets != null) for (Object t : targets) session.targets.add(t.toString());

            Nebula.ok("Session loaded: " + path);
            return session;
        } catch (Exception e) {
            Nebula.error("Load failed: " + e.getMessage());
            return null;
        }
    }

    public static List<String> listSessions() {
        try {
            return Files.list(SESSIONS_DIR)
                .filter(p -> p.toString().endsWith(".json"))
                .map(p -> p.getFileName().toString())
                .sorted()
                .collect(Collectors.toList());
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }

    private static String toJsonArray(List<String> list) {
        return "[" + list.stream().map(s -> "\"" + escapeJson(s) + "\"").collect(Collectors.joining(", ")) + "]";
    }

    private static String notesToJson(List<Map<String, String>> notes) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < notes.size(); i++) {
            Map<String, String> note = notes.get(i);
            sb.append("{\"title\":\"").append(escapeJson(note.get("title")))
              .append("\",\"content\":\"").append(escapeJson(note.get("content")))
              .append("\",\"ts\":\"").append(note.get("timestamp")).append("\"}");
            if (i < notes.size() - 1) sb.append(",");
        }
        return sb.append("]").toString();
    }

    static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
}

// ── Report Generator ─────────────────────────────────────────────────────────

class ReportGenerator {

    public static String generateHtml(NebulaSessData session) {
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html><head><title>Nebula Report - ").append(session.name).append("</title>\n");
        sb.append("<style>\n");
        sb.append("body{font-family:monospace;background:#0d0d1a;color:#e0e0e0;padding:2rem;line-height:1.6}\n");
        sb.append("h1,h2{color:#00d4ff} .flag{background:#0f3460;color:#00ff88;padding:6px 12px;");
        sb.append("border-radius:4px;margin:4px 0;display:inline-block}\n");
        sb.append(".note{background:#16213e;border-left:3px solid #00d4ff;padding:12px;");
        sb.append("margin:10px 0;border-radius:0 4px 4px 0}\n");
        sb.append(".note h3{color:#00d4ff;margin-bottom:6px} pre{white-space:pre-wrap;margin:0}\n");
        sb.append(".target{padding:4px 0;border-bottom:1px solid #222}\n");
        sb.append(".stat{display:inline-block;background:#16213e;border:1px solid #333;");
        sb.append("border-radius:6px;padding:12px 20px;margin:6px;text-align:center}\n");
        sb.append(".stat .num{font-size:2em;color:#00ff88;font-weight:bold}\n");
        sb.append(".stat .lbl{color:#888;font-size:.85em}\n");
        sb.append("footer{text-align:center;color:#555;margin-top:3rem}\n");
        sb.append("</style></head><body>\n");

        sb.append("<h1>🌌 Nebula CTF Report</h1>\n");
        sb.append("<p>Session: <strong>").append(session.name).append("</strong>");
        sb.append(" &bull; Started: ").append(session.startedAt).append("</p>\n");

        sb.append("<div style='margin:1.5rem 0'>\n");
        appendStat(sb, String.valueOf(session.flags.size()),   "Flags");
        appendStat(sb, String.valueOf(session.targets.size()), "Targets");
        appendStat(sb, String.valueOf(session.notes.size()),   "Notes");
        appendStat(sb, String.valueOf(session.totalResults()), "Results");
        sb.append("</div>\n");

        sb.append("<h2>🎯 Targets (").append(session.targets.size()).append(")</h2>\n");
        for (String t : session.targets)
            sb.append("<div class='target'>").append(escHtml(t)).append("</div>\n");

        sb.append("<h2>🚩 Flags (").append(session.flags.size()).append(")</h2>\n");
        if (session.flags.isEmpty()) {
            sb.append("<p style='color:#555'>No flags yet.</p>\n");
        } else {
            for (String f : session.flags)
                sb.append("<div class='flag'>").append(escHtml(f)).append("</div><br>\n");
        }

        sb.append("<h2>📝 Notes (").append(session.notes.size()).append(")</h2>\n");
        for (Map<String, String> n : session.notes) {
            sb.append("<div class='note'><h3>").append(escHtml(n.get("title"))).append("</h3>");
            sb.append("<pre>").append(escHtml(n.get("content"))).append("</pre>");
            sb.append("<small style='color:#555'>").append(n.get("timestamp")).append("</small></div>\n");
        }

        sb.append("<footer>Generated by Nebula CTF Toolkit v").append(Nebula.VERSION);
        sb.append(" &bull; ").append(LocalDateTime.now().toString()).append("</footer>\n");
        sb.append("</body></html>");
        return sb.toString();
    }

    public static void saveHtml(NebulaSessData session, String path) {
        try {
            Files.writeString(Path.of(path), generateHtml(session));
            Nebula.ok("HTML report saved: " + path);
        } catch (IOException e) {
            Nebula.error("Report save failed: " + e.getMessage());
        }
    }

    public static String generateMarkdown(NebulaSessData session) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Nebula CTF Report — ").append(session.name).append("\n\n");
        sb.append("**Started:** ").append(session.startedAt).append("\n\n---\n\n");
        sb.append("## Stats\n\n");
        sb.append("| Metric | Value |\n|--------|-------|\n");
        sb.append("| Flags | ").append(session.flags.size()).append(" |\n");
        sb.append("| Targets | ").append(session.targets.size()).append(" |\n");
        sb.append("| Notes | ").append(session.notes.size()).append(" |\n\n");
        sb.append("## Targets\n\n");
        for (String t : session.targets) sb.append("- `").append(t).append("`\n");
        sb.append("\n## Flags\n\n");
        for (String f : session.flags) sb.append("- `").append(f).append("`\n");
        sb.append("\n## Notes\n\n");
        for (Map<String, String> n : session.notes) {
            sb.append("### ").append(n.get("title")).append("\n\n```\n");
            sb.append(n.get("content")).append("\n```\n\n*").append(n.get("timestamp")).append("*\n\n");
        }
        return sb.toString();
    }

    private static void appendStat(StringBuilder sb, String num, String label) {
        sb.append("<div class='stat'><div class='num'>").append(num)
          .append("</div><div class='lbl'>").append(label).append("</div></div>\n");
    }

    private static String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }
}

// ── Network Engine ───────────────────────────────────────────────────────────

class NetworkEngine {

    private int timeout;
    private String userAgent;

    public NetworkEngine(int timeoutMs) {
        this.timeout   = timeoutMs;
        this.userAgent = "Nebula/" + Nebula.VERSION + " (CTF-Toolkit/Java)";
    }

    // Port scanning ─────────────────────────────────────

    public Map<Integer, String> portScan(String host, List<Integer> ports) {
        Map<Integer, String> open = new ConcurrentHashMap<>();
        List<Thread> threads = new ArrayList<>();

        for (int port : ports) {
            final int p = port;
            Thread t = new Thread(() -> {
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress(host, p), timeout);
                    open.put(p, getServiceName(p));
                } catch (IOException ignored) {}
            });
            threads.add(t);
            t.start();
        }
        for (Thread t : threads) {
            try { t.join(timeout + 500); } catch (InterruptedException ignored) {}
        }
        return open;
    }

    public static List<Integer> commonPorts() {
        return Arrays.asList(21,22,23,25,53,80,110,143,443,445,3306,3389,5432,8080,8443,6379,27017);
    }

    private String getServiceName(int port) {
        Map<Integer, String> services = new HashMap<>();
        services.put(21, "FTP");    services.put(22, "SSH");     services.put(23, "Telnet");
        services.put(25, "SMTP");   services.put(53, "DNS");     services.put(80, "HTTP");
        services.put(110,"POP3");   services.put(143,"IMAP");    services.put(443,"HTTPS");
        services.put(445,"SMB");    services.put(3306,"MySQL");  services.put(3389,"RDP");
        services.put(5432,"PgSQL"); services.put(8080,"HTTP-Alt");services.put(6379,"Redis");
        services.put(27017,"MongoDB");
        return services.getOrDefault(port, "unknown");
    }

    // HTTP requests ─────────────────────────────────────

    public HttpResult get(String url) {
        return request("GET", url, null, null);
    }

    public HttpResult post(String url, String body) {
        return request("POST", url, body, null);
    }

    public HttpResult request(String method, String urlStr, String body, Map<String, String> extraHeaders) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(timeout);
            conn.setReadTimeout(timeout);
            conn.setRequestProperty("User-Agent", userAgent);
            if (extraHeaders != null) {
                for (Map.Entry<String, String> h : extraHeaders.entrySet()) {
                    conn.setRequestProperty(h.getKey(), h.getValue());
                }
            }
            if (body != null) {
                conn.setDoOutput(true);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.getBytes());
                }
            }

            int status = conn.getResponseCode();
            Map<String, String> responseHeaders = new HashMap<>();
            for (Map.Entry<String, List<String>> h : conn.getHeaderFields().entrySet()) {
                if (h.getKey() != null)
                    responseHeaders.put(h.getKey(), String.join(", ", h.getValue()));
            }

            InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String responseBody = "";
            if (is != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
                    responseBody = reader.lines().collect(Collectors.joining("\n"));
                }
            }
            return new HttpResult(status, responseHeaders, responseBody);

        } catch (Exception e) {
            return new HttpResult(0, new HashMap<>(), "Error: " + e.getMessage());
        }
    }

    // DNS ───────────────────────────────────────────────

    public List<String> dnsLookup(String domain) {
        try {
            InetAddress[] addresses = InetAddress.getAllByName(domain);
            return Arrays.stream(addresses).map(InetAddress::getHostAddress).collect(Collectors.toList());
        } catch (UnknownHostException e) {
            return Collections.singletonList("ERROR: " + e.getMessage());
        }
    }

    public String reverseDns(String ip) {
        try {
            return InetAddress.getByName(ip).getCanonicalHostName();
        } catch (UnknownHostException e) {
            return "unknown";
        }
    }

    // Header analysis ───────────────────────────────────

    public Map<String, Object> analyzeHeaders(String url) {
        HttpResult result = get(url);
        Map<String, Object> analysis = new HashMap<>();
        analysis.put("status", result.status);
        analysis.put("server", result.headers.getOrDefault("Server", "hidden"));

        List<String> securityHeaders = Arrays.asList(
            "Strict-Transport-Security", "Content-Security-Policy",
            "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"
        );

        List<String> present = new ArrayList<>();
        List<String> missing = new ArrayList<>();
        Map<String, String> lowerHeaders = new HashMap<>();
        result.headers.forEach((k, v) -> lowerHeaders.put(k.toLowerCase(), v));

        for (String h : securityHeaders) {
            if (lowerHeaders.containsKey(h.toLowerCase())) present.add(h);
            else missing.add(h);
        }

        analysis.put("present", present);
        analysis.put("missing", missing);
        return analysis;
    }
}

// ── HTTP Result ───────────────────────────────────────────────────────────────

class HttpResult {
    public final int status;
    public final Map<String, String> headers;
    public final String body;

    public HttpResult(int status, Map<String, String> headers, String body) {
        this.status  = status;
        this.headers = headers;
        this.body    = body;
    }

    public boolean isSuccess() { return status >= 200 && status < 300; }
}

// ── Challenge Manager ─────────────────────────────────────────────────────────

class ChallengeManager {

    public enum Category { WEB, CRYPTO, FORENSICS, REVERSING, PWN, OSINT, MISC }
    public enum Difficulty { EASY, MEDIUM, HARD, INSANE }

    public static class Challenge {
        public final String id;
        public String name;
        public Category category;
        public Difficulty difficulty;
        public String description;
        public String url;
        public int points;
        public boolean solved;
        public String flag;
        public String notes;
        public long createdAt;
        public long solvedAt;

        public Challenge(String id, String name, Category cat, Difficulty diff, int pts) {
            this.id         = id;
            this.name       = name;
            this.category   = cat;
            this.difficulty = diff;
            this.points     = pts;
            this.solved     = false;
            this.createdAt  = System.currentTimeMillis();
        }

        public void solve(String flag) {
            this.solved   = true;
            this.flag     = flag;
            this.solvedAt = System.currentTimeMillis();
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"name\":\"%s\",\"category\":\"%s\",\"difficulty\":\"%s\"," +
                "\"points\":%d,\"solved\":%b,\"flag\":\"%s\",\"url\":\"%s\"}",
                id, SessionManager.escapeJson(name), category, difficulty,
                points, solved, flag != null ? SessionManager.escapeJson(flag) : "",
                url != null ? url : ""
            );
        }

        @Override
        public String toString() {
            String status = solved ? Nebula.ANSI_GREEN + "✓ SOLVED" + Nebula.ANSI_RESET
                                   : Nebula.ANSI_YELLOW + "○ open"  + Nebula.ANSI_RESET;
            return String.format("  [%s] %-30s %-12s %-8s %4d pts  %s",
                id, name, category, difficulty, points, status);
        }
    }

    private final List<Challenge> challenges = new ArrayList<>();
    private int nextId = 1;

    public Challenge add(String name, Category cat, Difficulty diff, int pts) {
        Challenge c = new Challenge(String.format("C%03d", nextId++), name, cat, diff, pts);
        challenges.add(c);
        Nebula.ok("Challenge added: " + name);
        return c;
    }

    public Optional<Challenge> find(String id) {
        return challenges.stream().filter(c -> c.id.equalsIgnoreCase(id)).findFirst();
    }

    public List<Challenge> byCategory(Category cat) {
        return challenges.stream().filter(c -> c.category == cat).collect(Collectors.toList());
    }

    public List<Challenge> unsolved() {
        return challenges.stream().filter(c -> !c.solved).collect(Collectors.toList());
    }

    public List<Challenge> solved() {
        return challenges.stream().filter(c -> c.solved).collect(Collectors.toList());
    }

    public int totalPoints() {
        return solved().stream().mapToInt(c -> c.points).sum();
    }

    public void printBoard() {
        System.out.println("\n" + Nebula.ANSI_CYAN + "  ══ Challenge Board ══" + Nebula.ANSI_RESET);
        System.out.printf("  %-6s %-30s %-12s %-8s %4s  %s%n", "ID", "Name", "Category", "Diff", "Pts", "Status");
        System.out.println("  " + "─".repeat(75));
        for (Challenge c : challenges) System.out.println(c);
        System.out.println("  " + "─".repeat(75));
        System.out.printf("  Solved: %d/%d   Score: %s%d%s pts%n%n",
            solved().size(), challenges.size(),
            Nebula.ANSI_GREEN, totalPoints(), Nebula.ANSI_RESET);
    }

    public void saveJson(String path) throws IOException {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < challenges.size(); i++) {
            sb.append(challenges.get(i).toJson());
            if (i < challenges.size() - 1) sb.append(",");
        }
        sb.append("]");
        Files.writeString(Path.of(path), sb.toString());
        Nebula.ok("Challenges saved: " + path);
    }
}

// ── Scoreboard ───────────────────────────────────────────────────────────────

class Scoreboard {

    private final ChallengeManager challenges;
    private final NebulaSessData session;

    public Scoreboard(ChallengeManager challenges, NebulaSessData session) {
        this.challenges = challenges;
        this.session    = session;
    }

    public void print() {
        System.out.println("\n" + Nebula.ANSI_CYAN + "  ══ Nebula Scoreboard ══" + Nebula.ANSI_RESET);
        System.out.println("  Session : " + session.name);
        System.out.println("  Score   : " + Nebula.ANSI_GREEN + challenges.totalPoints() + " pts" + Nebula.ANSI_RESET);
        System.out.println("  Solved  : " + challenges.solved().size() + "/" + challenges.unsolved().size() + " challenges");

        System.out.println("\n  By category:");
        for (ChallengeManager.Category cat : ChallengeManager.Category.values()) {
            List<ChallengeManager.Challenge> catChallenges = challenges.byCategory(cat);
            if (!catChallenges.isEmpty()) {
                long solvedCount = catChallenges.stream().filter(c -> c.solved).count();
                int catPts = catChallenges.stream().filter(c -> c.solved).mapToInt(c -> c.points).sum();
                System.out.printf("    %-12s %d/%d  (%d pts)%n",
                    cat, solvedCount, catChallenges.size(), catPts);
            }
        }
        System.out.println();
    }

    public String generateCsv() {
        StringBuilder sb = new StringBuilder("ID,Name,Category,Difficulty,Points,Solved,Flag\n");
        for (ChallengeManager.Challenge c : challenges.solved()) {
            sb.append(String.format("%s,\"%s\",%s,%s,%d,%b,\"%s\"%n",
                c.id, c.name, c.category, c.difficulty, c.points, c.solved,
                c.flag != null ? c.flag : ""));
        }
        return sb.toString();
    }
}

// ── CLI Interface ─────────────────────────────────────────────────────────────

class NebulaCLI {

    private NebulaSessData session;
    private ChallengeManager challenges;
    private NetworkEngine network;
    private Scanner scanner;
    private boolean running = true;

    private static final String BANNER =
        "\n" +
        "  ███╗   ██╗███████╗██████╗ ██╗   ██╗██╗      █████╗  \n" +
        "  ████╗  ██║██╔════╝██╔══██╗██║   ██║██║     ██╔══██╗ \n" +
        "  ██╔██╗ ██║█████╗  ██████╔╝██║   ██║██║     ███████║ \n" +
        "  ██║╚██╗██║██╔══╝  ██╔══██╗██║   ██║██║     ██╔══██║ \n" +
        "  ██║ ╚████║███████╗██████╔╝╚██████╔╝███████╗██║  ██║ \n" +
        "  ╚═╝  ╚═══╝╚══════╝╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝\n" +
        "\n" +
        "            CTF Toolkit v" + Nebula.VERSION + "  |  Java Engine\n";

    private static final String HELP =
        "\n  ── NEBULA JAVA ENGINE ──────────────────────────────\n" +
        "  GENERAL\n" +
        "    help              Show this help\n" +
        "    version           Show version\n" +
        "    banner            Show banner\n" +
        "    exit / quit       Save & exit\n" +
        "  SESSION\n" +
        "    session           Show session summary\n" +
        "    flag <value>      Record a flag\n" +
        "    target <host>     Add a target\n" +
        "    note <title>      Add a note\n" +
        "    save              Save session\n" +
        "    load <file>       Load session\n" +
        "    list-sessions     List saved sessions\n" +
        "    export-html       Export HTML report\n" +
        "    export-md         Export markdown report\n" +
        "  CHALLENGES\n" +
        "    challenges        Show challenge board\n" +
        "    add-chall         Add a challenge\n" +
        "    solve <id>        Mark challenge solved\n" +
        "    score             Show scoreboard\n" +
        "  NETWORK\n" +
        "    scan <host>       Port scan\n" +
        "    dns <domain>      DNS lookup\n" +
        "    rdns <ip>         Reverse DNS\n" +
        "    headers <url>     Analyze HTTP headers\n" +
        "    get <url>         HTTP GET request\n" +
        "  ─────────────────────────────────────────────────────\n";

    public void run(String[] args) {
        session    = new NebulaSessData("nebula_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")));
        challenges = new ChallengeManager();
        network    = new NetworkEngine(5000);
        scanner    = new Scanner(System.in);

        System.out.println(BANNER);
        Nebula.info("Type 'help' for commands. This is the Java engine.\n");

        while (running) {
            System.out.print(Nebula.ANSI_PURPLE + "nebula-java" + Nebula.ANSI_RESET +
                             Nebula.ANSI_CYAN    + " > "         + Nebula.ANSI_RESET);
            System.out.flush();
            if (!scanner.hasNextLine()) break;
            String line = scanner.nextLine().trim();
            if (!line.isEmpty()) handle(line);
        }
    }

    private void handle(String line) {
        String[] parts = line.split("\\s+", 3);
        String cmd = parts[0].toLowerCase();
        String[] args = Arrays.copyOfRange(parts, 1, parts.length);

        try {
            switch (cmd) {
                case "help":           System.out.println(HELP);           break;
                case "version":        System.out.println("  Nebula v" + Nebula.VERSION); break;
                case "banner":         System.out.println(BANNER);         break;
                case "exit": case "quit": cmdExit(); break;
                case "session":        session.printSummary();             break;
                case "flag":           if (args.length > 0) session.addFlag(String.join(" ", args)); else Nebula.error("Usage: flag <value>"); break;
                case "target":         if (args.length > 0) session.addTarget(args[0]); else Nebula.error("Usage: target <host>"); break;
                case "note":           cmdNote(args);                       break;
                case "save":           SessionManager.save(session);        break;
                case "load":           if (args.length > 0) { NebulaSessData s = SessionManager.load(args[0]); if (s != null) session = s; } break;
                case "list-sessions":  SessionManager.listSessions().forEach(f -> System.out.println("  " + f)); break;
                case "export-html":    cmdExportHtml(); break;
                case "export-md":      cmdExportMd();   break;
                case "challenges":     challenges.printBoard(); break;
                case "add-chall":      cmdAddChallenge(); break;
                case "solve":          if (args.length > 0) cmdSolve(args[0]); break;
                case "score":          new Scoreboard(challenges, session).print(); break;
                case "scan":           if (args.length > 0) cmdScan(args[0]); else Nebula.error("Usage: scan <host>"); break;
                case "dns":            if (args.length > 0) cmdDns(args[0]); else Nebula.error("Usage: dns <domain>"); break;
                case "rdns":           if (args.length > 0) System.out.println("  " + network.reverseDns(args[0])); else Nebula.error("Usage: rdns <ip>"); break;
                case "headers":        if (args.length > 0) cmdHeaders(args[0]); else Nebula.error("Usage: headers <url>"); break;
                case "get":            if (args.length > 0) cmdGet(args[0]); else Nebula.error("Usage: get <url>"); break;
                default:               Nebula.error("Unknown command: " + cmd + ". Type 'help'."); break;
            }
        } catch (Exception e) {
            Nebula.error("Error: " + e.getMessage());
        }
    }

    private void cmdExit() {
        Nebula.info("Saving session...");
        SessionManager.save(session);
        running = false;
    }

    private void cmdNote(String[] args) {
        String title = args.length > 0 ? String.join(" ", args) : prompt("Title: ");
        String content = prompt("Content: ");
        session.addNote(title, content);
    }

    private void cmdExportHtml() {
        String path = "nebula_report_" + System.currentTimeMillis() / 1000 + ".html";
        ReportGenerator.saveHtml(session, path);
    }

    private void cmdExportMd() {
        String path = "nebula_report_" + System.currentTimeMillis() / 1000 + ".md";
        try {
            Files.writeString(Path.of(path), ReportGenerator.generateMarkdown(session));
            Nebula.ok("Markdown saved: " + path);
        } catch (IOException e) {
            Nebula.error("Export failed: " + e.getMessage());
        }
    }

    private void cmdAddChallenge() {
        String name  = prompt("Challenge name: ");
        String catStr  = prompt("Category (WEB/CRYPTO/FORENSICS/REVERSING/PWN/OSINT/MISC): ").toUpperCase();
        String diffStr = prompt("Difficulty (EASY/MEDIUM/HARD/INSANE): ").toUpperCase();
        String ptsStr  = prompt("Points: ");
        try {
            ChallengeManager.Category cat   = ChallengeManager.Category.valueOf(catStr);
            ChallengeManager.Difficulty diff = ChallengeManager.Difficulty.valueOf(diffStr);
            int pts = Integer.parseInt(ptsStr.trim());
            ChallengeManager.Challenge c = challenges.add(name, cat, diff, pts);
            String url = prompt("URL (leave blank to skip): ");
            if (!url.isBlank()) c.url = url;
        } catch (IllegalArgumentException e) {
            Nebula.error("Invalid input: " + e.getMessage());
        }
    }

    private void cmdSolve(String id) {
        Optional<ChallengeManager.Challenge> opt = challenges.find(id);
        if (opt.isPresent()) {
            String flag = prompt("Flag: ");
            opt.get().solve(flag);
            session.addFlag(flag);
            Nebula.ok("Challenge " + id + " marked as solved! +" + opt.get().points + " pts");
        } else {
            Nebula.error("Challenge not found: " + id);
        }
    }

    private void cmdScan(String host) {
        Nebula.info("Scanning " + host + "...");
        Map<Integer, String> open = network.portScan(host, NetworkEngine.commonPorts());
        if (open.isEmpty()) {
            Nebula.warn("No common ports open.");
        } else {
            System.out.println("  Open ports on " + host + ":");
            open.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .forEach(e -> System.out.printf("  [%s%d%s] %s%n",
                    Nebula.ANSI_GREEN, e.getKey(), Nebula.ANSI_RESET, e.getValue()));
        }
        session.addResult("net", Map.of("host", host, "open_ports", open));
    }

    private void cmdDns(String domain) {
        List<String> ips = network.dnsLookup(domain);
        System.out.println("  DNS results for " + domain + ":");
        ips.forEach(ip -> System.out.println("  " + ip));
    }

    private void cmdHeaders(String url) {
        Map<String, Object> analysis = network.analyzeHeaders(url);
        System.out.println("  Header analysis for " + url);
        System.out.println("  Status : " + analysis.get("status"));
        System.out.println("  Server : " + analysis.get("server"));
        System.out.println("  Present: " + Nebula.ANSI_GREEN + analysis.get("present") + Nebula.ANSI_RESET);
        System.out.println("  Missing: " + Nebula.ANSI_YELLOW + analysis.get("missing") + Nebula.ANSI_RESET);
    }

    private void cmdGet(String url) {
        Nebula.info("GET " + url);
        HttpResult r = network.get(url);
        System.out.println("  Status : " + r.status);
        System.out.println("  Headers:");
        r.headers.forEach((k, v) -> System.out.println("    " + k + ": " + v));
        System.out.println("  Body preview:");
        System.out.println(r.body.substring(0, Math.min(r.body.length(), 500)));
    }

    private String prompt(String msg) {
        System.out.print("  " + msg);
        return scanner.hasNextLine() ? scanner.nextLine().trim() : "";
    }
}

// ── Swing GUI Dashboard ───────────────────────────────────────────────────────

class NebulaDashboard {

    private JFrame frame;
    private JTabbedPane tabs;
    private NebulaSessData session;
    private ChallengeManager challenges;
    private NetworkEngine network;
    private DefaultListModel<String> flagsModel;
    private DefaultListModel<String> targetsModel;
    private JTextArea outputArea;

    private static final Color BG      = new Color(13, 13, 26);
    private static final Color SURFACE = new Color(22, 33, 62);
    private static final Color ACCENT  = new Color(0, 212, 255);
    private static final Color GREEN   = new Color(0, 255, 136);
    private static final Color FG      = new Color(224, 224, 224);
    private static final Color YELLOW  = new Color(255, 170, 0);

    public void launch() {
        session    = new NebulaSessData("nebula_gui_" + System.currentTimeMillis());
        challenges = new ChallengeManager();
        network    = new NetworkEngine(5000);

        frame = new JFrame("Nebula CTF Toolkit v" + Nebula.VERSION);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1100, 700);
        frame.getContentPane().setBackground(BG);

        buildUI();

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void buildUI() {
        frame.setLayout(new BorderLayout());

        JPanel header = buildHeader();
        frame.add(header, BorderLayout.NORTH);

        tabs = new JTabbedPane();
        tabs.setBackground(BG);
        tabs.setForeground(ACCENT);
        tabs.setFont(new Font("Monospaced", Font.BOLD, 13));

        tabs.addTab("📊 Dashboard", buildDashboard());
        tabs.addTab("🚩 Session",   buildSessionTab());
        tabs.addTab("🌐 Web",       buildWebTab());
        tabs.addTab("🔐 Crypto",    buildCryptoTab());
        tabs.addTab("🧩 Challenges",buildChallengesTab());
        tabs.addTab("📋 Output",    buildOutputTab());

        frame.add(tabs, BorderLayout.CENTER);
        frame.add(buildStatusBar(), BorderLayout.SOUTH);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        p.setBackground(new Color(10, 10, 20));
        p.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        JLabel title = new JLabel("🌌  NEBULA  CTF TOOLKIT");
        title.setFont(new Font("Monospaced", Font.BOLD, 18));
        title.setForeground(ACCENT);
        p.add(title);
        JLabel version = new JLabel(" v" + Nebula.VERSION);
        version.setForeground(new Color(100, 100, 150));
        version.setFont(new Font("Monospaced", Font.PLAIN, 12));
        p.add(version);
        return p;
    }

    private JPanel buildDashboard() {
        JPanel p = darkPanel(new GridLayout(2, 3, 12, 12));
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        p.add(statCard("🚩 Flags",     "0",  GREEN));
        p.add(statCard("🎯 Targets",   "0",  ACCENT));
        p.add(statCard("📝 Notes",     "0",  YELLOW));
        p.add(statCard("🏆 Points",    "0",  YELLOW));
        p.add(statCard("✅ Solved",    "0",  GREEN));
        p.add(statCard("⚔️ Open",      "0",  new Color(255,80,80)));
        return p;
    }

    private JPanel statCard(String label, String value, Color valueColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(SURFACE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 60, 90), 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        JLabel num = new JLabel(value, SwingConstants.CENTER);
        num.setFont(new Font("Monospaced", Font.BOLD, 36));
        num.setForeground(valueColor);
        JLabel lbl = new JLabel(label, SwingConstants.CENTER);
        lbl.setFont(new Font("Monospaced", Font.PLAIN, 13));
        lbl.setForeground(FG);
        card.add(num, BorderLayout.CENTER);
        card.add(lbl, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildSessionTab() {
        JPanel p = darkPanel(new BorderLayout(10, 10));
        p.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel left = darkPanel(new BorderLayout(5, 5));
        flagsModel = new DefaultListModel<>();
        JList<String> flagsList = styledList(flagsModel);
        left.add(new JLabel("  Flags:") {{ setForeground(ACCENT); setFont(new Font("Monospaced", Font.BOLD, 13)); }}, BorderLayout.NORTH);
        left.add(new JScrollPane(flagsList), BorderLayout.CENTER);

        JPanel flagInput = darkPanel(new BorderLayout(5, 0));
        JTextField flagField = darkField();
        JButton addFlag = styledButton("Add Flag");
        addFlag.addActionListener(e -> {
            String f = flagField.getText().trim();
            if (!f.isEmpty()) {
                session.addFlag(f);
                flagsModel.addElement(f);
                flagField.setText("");
            }
        });
        flagInput.add(flagField, BorderLayout.CENTER);
        flagInput.add(addFlag, BorderLayout.EAST);
        left.add(flagInput, BorderLayout.SOUTH);

        JPanel right = darkPanel(new BorderLayout(5, 5));
        targetsModel = new DefaultListModel<>();
        JList<String> targetsList = styledList(targetsModel);
        right.add(new JLabel("  Targets:") {{ setForeground(ACCENT); setFont(new Font("Monospaced", Font.BOLD, 13)); }}, BorderLayout.NORTH);
        right.add(new JScrollPane(targetsList), BorderLayout.CENTER);

        JPanel targetInput = darkPanel(new BorderLayout(5, 0));
        JTextField targetField = darkField();
        JButton addTarget = styledButton("Add Target");
        addTarget.addActionListener(e -> {
            String t = targetField.getText().trim();
            if (!t.isEmpty()) {
                session.addTarget(t);
                targetsModel.addElement(t);
                targetField.setText("");
            }
        });
        targetInput.add(targetField, BorderLayout.CENTER);
        targetInput.add(addTarget, BorderLayout.EAST);
        right.add(targetInput, BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
        split.setDividerLocation(0.5);
        split.setResizeWeight(0.5);
        split.setBackground(BG);

        JPanel buttons = darkPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton saveBtn = styledButton("💾 Save Session");
        saveBtn.addActionListener(e -> { SessionManager.save(session); logOutput("Session saved."); });
        JButton htmlBtn = styledButton("📄 Export HTML");
        htmlBtn.addActionListener(e -> {
            String path = "nebula_report_" + System.currentTimeMillis()/1000 + ".html";
            ReportGenerator.saveHtml(session, path);
            logOutput("HTML report saved: " + path);
        });
        buttons.add(saveBtn);
        buttons.add(htmlBtn);

        p.add(split, BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildWebTab() {
        JPanel p = darkPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel controls = darkPanel(new GridLayout(4, 3, 8, 8));

        JLabel urlLabel = new JLabel("  URL: ");
        urlLabel.setForeground(FG);
        JTextField urlField = darkField();
        JLabel paramLabel = new JLabel("  Param: ");
        paramLabel.setForeground(FG);
        JTextField paramField = darkField();
        paramField.setText("id");

        JButton sqliBtn  = styledButton("🗃️ SQLi Test");
        JButton xssBtn   = styledButton("💉 XSS Test");
        JButton fuzzBtn  = styledButton("📁 Dir Fuzz");
        JButton hdrsBtn  = styledButton("🔒 Headers");
        JButton getBtn   = styledButton("🌐 GET");

        controls.add(urlLabel);   controls.add(urlField);
        controls.add(sqliBtn);    controls.add(paramLabel);
        controls.add(paramField); controls.add(xssBtn);
        controls.add(fuzzBtn);    controls.add(hdrsBtn);
        controls.add(getBtn);     controls.add(darkPanel(new FlowLayout()));

        JTextArea webOutput = darkTextArea();
        JScrollPane scroll = new JScrollPane(webOutput);

        sqliBtn.addActionListener(e -> {
            String url = urlField.getText().trim(), param = paramField.getText().trim();
            if (url.isEmpty()) return;
            webOutput.setText("Testing SQLi on " + url + " [" + param + "]...\n");
            // Delegate to Python engine or show instructions
            webOutput.append("Run from Python engine: sqli " + url + "\n");
        });

        getBtn.addActionListener(e -> {
            String url = urlField.getText().trim();
            if (url.isEmpty()) return;
            new Thread(() -> {
                HttpResult r = network.get(url);
                SwingUtilities.invokeLater(() -> {
                    webOutput.setText("GET " + url + "\nStatus: " + r.status + "\n\nHeaders:\n");
                    r.headers.forEach((k, v) -> webOutput.append("  " + k + ": " + v + "\n"));
                    webOutput.append("\nBody:\n" + r.body.substring(0, Math.min(r.body.length(), 2000)));
                });
            }).start();
        });

        hdrsBtn.addActionListener(e -> {
            String url = urlField.getText().trim();
            if (url.isEmpty()) return;
            new Thread(() -> {
                Map<String, Object> analysis = network.analyzeHeaders(url);
                SwingUtilities.invokeLater(() -> {
                    webOutput.setText("Header Analysis: " + url + "\n\n");
                    webOutput.append("Server : " + analysis.get("server") + "\n");
                    webOutput.append("Present: " + analysis.get("present") + "\n");
                    webOutput.append("Missing: " + analysis.get("missing") + "\n");
                });
            }).start();
        });

        p.add(controls, BorderLayout.NORTH);
        p.add(scroll,   BorderLayout.CENTER);
        return p;
    }

    private JPanel buildCryptoTab() {
        JPanel p = darkPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel top = darkPanel(new GridLayout(2, 4, 8, 8));
        JTextField inputField = darkField();
        JTextArea  cryptoOut  = darkTextArea();

        JButton b64Enc  = styledButton("Base64 Enc");
        JButton b64Dec  = styledButton("Base64 Dec");
        JButton hexEnc  = styledButton("Hex Enc");
        JButton hexDec  = styledButton("Hex Dec");
        JButton rot13   = styledButton("ROT-13");
        JButton md5     = styledButton("MD5 Hash");
        JButton sha256  = styledButton("SHA-256");
        JButton identH  = styledButton("Identify Hash");

        top.add(new JLabel("  Input:") {{ setForeground(FG); }});
        top.add(inputField);
        top.add(b64Enc); top.add(b64Dec);
        top.add(hexEnc); top.add(hexDec);
        top.add(rot13);  top.add(md5);
        top.add(sha256); top.add(identH);

        b64Enc.addActionListener(e -> {
            try { cryptoOut.setText(java.util.Base64.getEncoder().encodeToString(inputField.getText().getBytes())); }
            catch (Exception ex) { cryptoOut.setText("Error: " + ex.getMessage()); }
        });
        b64Dec.addActionListener(e -> {
            try { cryptoOut.setText(new String(java.util.Base64.getDecoder().decode(inputField.getText().trim()))); }
            catch (Exception ex) { cryptoOut.setText("Error: " + ex.getMessage()); }
        });
        hexEnc.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (byte b : inputField.getText().getBytes()) sb.append(String.format("%02x", b));
            cryptoOut.setText(sb.toString());
        });
        hexDec.addActionListener(e -> {
            try {
                String hex = inputField.getText().trim();
                byte[] bytes = new byte[hex.length()/2];
                for (int i = 0; i < bytes.length; i++)
                    bytes[i] = (byte) Integer.parseInt(hex.substring(i*2, i*2+2), 16);
                cryptoOut.setText(new String(bytes));
            } catch (Exception ex) { cryptoOut.setText("Error: " + ex.getMessage()); }
        });
        rot13.addActionListener(e -> {
            String in = inputField.getText();
            StringBuilder sb = new StringBuilder();
            for (char c : in.toCharArray()) {
                if (Character.isLetter(c)) {
                    int base = Character.isUpperCase(c) ? 'A' : 'a';
                    sb.append((char)((c - base + 13) % 26 + base));
                } else sb.append(c);
            }
            cryptoOut.setText(sb.toString());
        });
        md5.addActionListener(e -> {
            try {
                MessageDigest md = MessageDigest.getInstance("MD5");
                byte[] hash = md.digest(inputField.getText().getBytes());
                StringBuilder sb = new StringBuilder();
                for (byte b : hash) sb.append(String.format("%02x", b));
                cryptoOut.setText("MD5: " + sb);
            } catch (Exception ex) { cryptoOut.setText("Error: " + ex.getMessage()); }
        });
        sha256.addActionListener(e -> {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hash = md.digest(inputField.getText().getBytes());
                StringBuilder sb = new StringBuilder();
                for (byte b : hash) sb.append(String.format("%02x", b));
                cryptoOut.setText("SHA-256: " + sb);
            } catch (Exception ex) { cryptoOut.setText("Error: " + ex.getMessage()); }
        });
        identH.addActionListener(e -> {
            String h = inputField.getText().trim();
            List<String> types = new ArrayList<>();
            if (h.matches("[a-fA-F0-9]{32}")) types.add("MD5/NTLM");
            if (h.matches("[a-fA-F0-9]{40}")) types.add("SHA-1");
            if (h.matches("[a-fA-F0-9]{64}")) types.add("SHA-256");
            if (h.matches("[a-fA-F0-9]{128}")) types.add("SHA-512");
            if (h.matches("\\$2[ayb]\\$.{56}")) types.add("bcrypt");
            cryptoOut.setText(types.isEmpty() ? "Unknown hash type" : "Possible: " + String.join(", ", types));
        });

        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(cryptoOut), BorderLayout.CENTER);
        return p;
    }

    private JPanel buildChallengesTab() {
        JPanel p = darkPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JTextArea board = darkTextArea();
        board.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JPanel buttons = darkPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        JButton refresh = styledButton("🔄 Refresh");
        JButton addBtn  = styledButton("➕ Add Challenge");
        JButton score   = styledButton("🏆 Score");

        refresh.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append(String.format("  %-6s %-25s %-12s %-8s %5s  %s%n",
                "ID", "Name", "Category", "Diff", "Pts", "Status"));
            sb.append("  ").append("─".repeat(70)).append("\n");
            for (ChallengeManager.Challenge c : challenges.unsolved()) {
                sb.append(String.format("  %-6s %-25s %-12s %-8s %5d  [ open ]%n",
                    c.id, c.name, c.category, c.difficulty, c.points));
            }
            for (ChallengeManager.Challenge c : challenges.solved()) {
                sb.append(String.format("  %-6s %-25s %-12s %-8s %5d  [SOLVED]%n",
                    c.id, c.name, c.category, c.difficulty, c.points));
            }
            board.setText(sb.toString());
        });

        addBtn.addActionListener(e -> {
            String name = JOptionPane.showInputDialog(frame, "Challenge name:");
            if (name == null || name.isBlank()) return;
            String[] cats  = {"WEB","CRYPTO","FORENSICS","REVERSING","PWN","OSINT","MISC"};
            String cat     = (String) JOptionPane.showInputDialog(frame, "Category:", "Add", JOptionPane.PLAIN_MESSAGE, null, cats, cats[0]);
            String[] diffs = {"EASY","MEDIUM","HARD","INSANE"};
            String diff    = (String) JOptionPane.showInputDialog(frame, "Difficulty:", "Add", JOptionPane.PLAIN_MESSAGE, null, diffs, diffs[0]);
            String ptsStr  = JOptionPane.showInputDialog(frame, "Points:");
            try {
                int pts = Integer.parseInt(ptsStr.trim());
                challenges.add(name, ChallengeManager.Category.valueOf(cat), ChallengeManager.Difficulty.valueOf(diff), pts);
                refresh.doClick();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input: " + ex.getMessage());
            }
        });

        score.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame,
                String.format("Score: %d pts\nSolved: %d/%d challenges",
                    challenges.totalPoints(),
                    challenges.solved().size(),
                    challenges.solved().size() + challenges.unsolved().size()));
        });

        buttons.add(refresh);
        buttons.add(addBtn);
        buttons.add(score);

        p.add(buttons, BorderLayout.NORTH);
        p.add(new JScrollPane(board), BorderLayout.CENTER);
        return p;
    }

    private JPanel buildOutputTab() {
        JPanel p = darkPanel(new BorderLayout());
        p.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        outputArea = darkTextArea();
        outputArea.setText("  Nebula Output Log\n  ─────────────────\n");
        p.add(new JScrollPane(outputArea), BorderLayout.CENTER);
        JPanel bottom = darkPanel(new FlowLayout(FlowLayout.LEFT));
        JButton clearBtn = styledButton("Clear");
        clearBtn.addActionListener(e -> outputArea.setText(""));
        bottom.add(clearBtn);
        p.add(bottom, BorderLayout.SOUTH);
        return p;
    }

    private JLabel buildStatusBar() {
        JLabel bar = new JLabel("  Nebula CTF Toolkit v" + Nebula.VERSION + "  |  Ready");
        bar.setForeground(new Color(100, 100, 150));
        bar.setFont(new Font("Monospaced", Font.PLAIN, 11));
        bar.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
        bar.setBackground(new Color(8, 8, 16));
        bar.setOpaque(true);
        return bar;
    }

    private void logOutput(String msg) {
        if (outputArea != null)
            outputArea.append("[" + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "] " + msg + "\n");
    }

    // ── UI helpers ─────────────────────────────────────

    private JPanel darkPanel(LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setBackground(BG);
        return p;
    }

    private JTextField darkField() {
        JTextField f = new JTextField();
        f.setBackground(SURFACE);
        f.setForeground(FG);
        f.setCaretColor(ACCENT);
        f.setFont(new Font("Monospaced", Font.PLAIN, 13));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50,60,90)),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        return f;
    }

    private JTextArea darkTextArea() {
        JTextArea a = new JTextArea();
        a.setBackground(new Color(8, 8, 18));
        a.setForeground(FG);
        a.setFont(new Font("Monospaced", Font.PLAIN, 12));
        a.setCaretColor(ACCENT);
        a.setLineWrap(true);
        a.setWrapStyleWord(true);
        a.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        return a;
    }

    private <E> JList<E> styledList(ListModel<E> model) {
        JList<E> list = new JList<>(model);
        list.setBackground(new Color(8, 8, 18));
        list.setForeground(GREEN);
        list.setFont(new Font("Monospaced", Font.PLAIN, 12));
        list.setSelectionBackground(SURFACE);
        list.setSelectionForeground(ACCENT);
        return list;
    }

    private JButton styledButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(SURFACE);
        btn.setForeground(ACCENT);
        btn.setFont(new Font("Monospaced", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 100, 150)),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)
        ));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(0, 50, 80)); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(SURFACE); }
        });
        return btn;
    }
}
